//  //Fancybox Javascript
//  function fancythumb(){
//  $(".fancybox-thumb").fancybox({
//         prevEffect  : 'none',
//         nextEffect  : 'none',
//         openEffect  : 'elastic',
//         closeEffect : 'elastic',

//         // helpers : {
//         //     thumbs  : {
//         //         width   : 100,
//         //         height  : 100
//         //     }
//         // }
//     });
//  }
//  	var $containter = $('#container');
//     $containter.imagesLoaded( function(){
//         $containter.masonry({
//           itemSelector: '.box',
//           isAnimated: !Modernizr.csstransitions,
//           isFitWidth: true
//      });
// });
// 
// 
function fancybox(){
	$('.fancybox').fancybox();
}